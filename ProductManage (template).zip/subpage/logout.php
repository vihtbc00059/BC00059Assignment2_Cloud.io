<?php
    unset($_SESSION['user']);
?>
<meta http-equiv="Refresh" content="0; url=index.php?sub=login">